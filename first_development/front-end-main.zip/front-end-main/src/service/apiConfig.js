var apiConfig = {
    development: {
        bearer_token : '1234567890',
        API_URL : 'https://api.se-rmutl.net',
    },
    production: {
        bearer_token : '1234567890',
        API_URL : 'https://api.se-rmutl.net',
    }
};
module.exports = apiConfig;